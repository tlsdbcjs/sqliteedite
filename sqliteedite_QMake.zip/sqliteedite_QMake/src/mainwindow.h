#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "sqltextedit.h"
#include "sqlitedb.h"
#include "RemoteDatabase.h"

#include <QMainWindow>
#include <QMap>

class QIntValidator;
class QLabel;
class SqliteTableModel;
class DbStructureModel;
class EditDialog;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    DBBrowserDB& getDb() { return db; }
    const RemoteDatabase& getRemote() const { return m_remoteDb; }

    struct PlotSettings
    {
        int lineStyle;
        int pointShape;
        QColor colour;

        friend QDataStream& operator<<(QDataStream& stream, const MainWindow::PlotSettings& object)
        {
            stream << object.lineStyle;
            stream << object.pointShape;
            stream << object.colour;

            return stream;
        }
        friend QDataStream& operator>>(QDataStream& stream, MainWindow::PlotSettings& object)
        {
            stream >> object.lineStyle;
            stream >> object.pointShape;
            stream >> object.colour;

            return stream;
        }
    };

    struct BrowseDataTableSettings
    {
        int sortOrderIndex;
        Qt::SortOrder sortOrderMode;
        QMap<int, int> columnWidths;
        QMap<int, QString> filterValues;
        QMap<int, QString> displayFormats;
        bool showRowid;
        QString encoding;
        QString plotXAxis;
        QMap<QString, PlotSettings> plotYAxes;

        friend QDataStream& operator<<(QDataStream& stream, const MainWindow::BrowseDataTableSettings& object)
        {
            stream << object.sortOrderIndex;
            stream << static_cast<int>(object.sortOrderMode);
            stream << object.columnWidths;
            stream << object.filterValues;
            stream << object.displayFormats;
            stream << object.showRowid;
            stream << object.encoding;
            stream << object.plotXAxis;
            stream << object.plotYAxes;

            return stream;
        }
        friend QDataStream& operator>>(QDataStream& stream, MainWindow::BrowseDataTableSettings& object)
        {
            stream >> object.sortOrderIndex;
            int sortordermode;
            stream >> sortordermode;
            object.sortOrderMode = static_cast<Qt::SortOrder>(sortordermode);
            stream >> object.columnWidths;
            stream >> object.filterValues;
            stream >> object.displayFormats;
            stream >> object.showRowid;
            stream >> object.encoding;

            // Versions pre 3.10.0 didn't store the following information in their project files.
            // To be absolutely sure that nothing strange happens when we read past the stream for
            // those cases, check for the end of the stream here.
            if(stream.atEnd())
                return stream;

            stream >> object.plotXAxis;
            stream >> object.plotYAxes;

            return stream;
        }
    };

    enum Tabs
    {
        BrowseTab,
        StructureTab
    };

private:
    Ui::MainWindow *ui;
    QIntValidator* gotoValidator;

    struct PragmaValues
    {
        int autovacuum;
        int automatic_index;
        int checkpoint_fullsync;
        int foreign_keys;
        int fullfsync;
        int ignore_check_constraints;
        QString journal_mode;
        int journal_size_limit;
        QString locking_mode;
        int max_page_count;
        int page_size;
        int recursive_triggers;
        int secure_delete;
        int synchronous;
        int temp_store;
        int user_version;
        int wal_autocheckpoint;
    } pragmaValues;

    enum { MaxRecentFiles = 5 };

    SqliteTableModel* m_browseTableModel;
    SqliteTableModel* m_currentTabTableModel;
    SqliteTableModel* m_currentPlotModel;

    QMap<QString, BrowseDataTableSettings> browseTableSettings;
    RemoteDatabase m_remoteDb;
    DBBrowserDB db;
    DbStructureModel* dbStructureModel;
    EditDialog* editDock;

    QString defaultBrowseTableEncoding;
    QAction *recentFileActs[MaxRecentFiles];
    QAction *recentSeparatorAct;
    QMenu *popupTableMenu;

    QLabel* statusEncodingLabel;
    QLabel* statusEncryptionLabel;
    QLabel* statusReadOnlyLabel;

    void init();
    void setCurrentFile(const QString& fileName);
    void loadExtensionsFromSettings();
    void activateFields(bool enable = true);

public slots:
    bool fileOpen(const QString& fileName = QString(), bool dontAddToRecentFiles = false);
    void refresh();
    void switchToBrowseDataTab(QString tableToBrowse = QString());
    void populateStructure();

private slots:
    void createTreeContextMenu(const QPoint & qPoint);
    void openRecentFile();
    void populateTable();
    void clearTableBrowser();
    bool fileClose();
    void loadPragmas();
    void setRecordsetLabel();
    void dataTableSelectionChanged(const QModelIndex& index);
    void showRowidColumn(bool show);
    void changeTreeSelection();
    void reloadSettings();
};

#endif // MAINWINDOW_H
