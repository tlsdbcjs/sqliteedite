#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "sqlitetablemodel.h"
#include "Settings.h"
#include "FileDialog.h"
#include "DbStructureModel.h"
#include "SqlUiLexer.h"
#include "EditDialog.h"

#include <QDebug>
#include <QMessageBox>
#include <QShortcut>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_browseTableModel(new SqliteTableModel(this, &db, Settings::getSettingsValue("db", "prefetchsize").toInt())),
    m_currentTabTableModel(m_browseTableModel),
    editDock(new EditDialog(this)),
    gotoValidator(new QIntValidator(0, 0, this))
{
    ui->setupUi(this);
    init();

    activateFields(false);
}

MainWindow::~MainWindow()
{
    delete gotoValidator;
    delete ui;
}

void MainWindow::init()
{

    // Connect SQL logging and database state setting to main window
    //connect(&db, SIGNAL(dbChanged(bool)), this, SLOT(dbState(bool)));
    connect(&db, SIGNAL(structureUpdated()), this, SLOT(populateStructure()));

    // Set up filters
    connect(ui->dataTable->filterHeader(), SIGNAL(filterChanged(int,QString)), this, SLOT(updateFilter(int,QString)));
    connect(m_browseTableModel, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(dataTableSelectionChanged(QModelIndex)));

    dbStructureModel = new DbStructureModel(db, this);

    // Set up DB structure tab
    ui->dbTreeWidget->setModel(dbStructureModel);
    ui->dbTreeWidget->setColumnHidden(1, true);
    ui->dbTreeWidget->setColumnWidth(0, 300);

    // Set up the table combo box in the Browse Data tab
    ui->browse_T_ComboBox->setModel(dbStructureModel);

    // Add keyboard shortcuts
    QShortcut* shortcutBrowseRefreshF5 = new QShortcut(QKeySequence("F5"), this);
    connect(shortcutBrowseRefreshF5, SIGNAL(activated()), this, SLOT(refresh()));
    QShortcut* shortcutBrowseRefreshCtrlR = new QShortcut(QKeySequence("Ctrl+R"), this);
    connect(shortcutBrowseRefreshCtrlR, SIGNAL(activated()), this, SLOT(refresh()));


    // Set statusbar fields
    statusEncryptionLabel = new QLabel(ui->statusbar);
    statusEncryptionLabel->setEnabled(false);
    statusEncryptionLabel->setVisible(false);
    statusEncryptionLabel->setText(tr("Encrypted"));
    statusEncryptionLabel->setToolTip(tr("Database is encrypted using SQLCipher"));
    ui->statusbar->addPermanentWidget(statusEncryptionLabel);

    statusReadOnlyLabel = new QLabel(ui->statusbar);
    statusReadOnlyLabel->setEnabled(false);
    statusReadOnlyLabel->setVisible(false);
    statusReadOnlyLabel->setText(tr("Read only"));
    statusReadOnlyLabel->setToolTip(tr("Database file is read only. Editing the database is disabled."));
    ui->statusbar->addPermanentWidget(statusReadOnlyLabel);

    statusEncodingLabel = new QLabel(ui->statusbar);
    statusEncodingLabel->setEnabled(false);
    statusEncodingLabel->setText("UTF-8");
    statusEncodingLabel->setToolTip(tr("Database encoding"));
    ui->statusbar->addPermanentWidget(statusEncodingLabel);

    // Create popup menus
    popupTableMenu = new QMenu(this);
    popupTableMenu->addAction(ui->fileOpenAction);

    // Create the actions for the recently opened dbs list
    for(int i = 0; i < MaxRecentFiles; ++i) {
        recentFileActs[i] = new QAction(this);
        recentFileActs[i]->setVisible(false);
        connect(recentFileActs[i], SIGNAL(triggered()), this, SLOT(openRecentFile()));
    }
    for(int i = 0; i < MaxRecentFiles; ++i)
        ui->fileMenu->insertAction(ui->fileExitAction, recentFileActs[i]);
    recentSeparatorAct = ui->fileMenu->insertSeparator(ui->fileExitAction);


    // Set up DB structure tab
    dbStructureModel = new DbStructureModel(db, this);

    // Set up the table combo box in the Browse Data tab
    ui->browse_T_ComboBox->setModel(dbStructureModel);


    // Connect some more signals and slots
    connect(ui->fileOpenAction, SIGNAL(openFile(QString)), this, SLOT(fileOpen(QString)));
    connect(ui->dbTreeWidget->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(changeTreeSelection()));

    // Load all settings
    reloadSettings();
}

bool MainWindow::fileOpen(const QString& fileName, bool dontAddToRecentFiles)
{

    bool retval = false;

    QString wFile = fileName;
    if (!QFile::exists(wFile))
    {
        wFile = FileDialog::getOpenFileName(
                    this,
                    tr("Choose a database file")
#ifndef Q_OS_MAC // Filters on OS X are buggy
                    , FileDialog::getSqlDatabaseFileFilter()
#endif
                    );
    }

    if(QFile::exists(wFile) )
    {
        // Close the database. If the user didn't want to close it, though, stop here
        if (db.isOpen())
            if(!fileClose())
                return false;

        // Try opening it as a project file first
        // No project file; so it should be a database file
        if(db.open(wFile))
        {
            statusEncodingLabel->setText(db.getPragma("encoding"));
            statusEncryptionLabel->setVisible(db.encrypted());
            statusReadOnlyLabel->setVisible(db.readOnly());
            setCurrentFile(wFile);
        //    if(!dontAddToRecentFiles)
        //        addToRecentFilesMenu(wFile);
        //    openSqlTab(true);
            loadExtensionsFromSettings();
            if(ui->mainTab->currentIndex() == BrowseTab)
                populateTable();
            retval = true;
        } else {
            QMessageBox::warning(this, qApp->applicationName(), tr("Invalid file format."));
            return false;
        }
    }

    return retval;
}

void MainWindow::openRecentFile()
{
    QAction *action = qobject_cast<QAction *>(sender());
    if (action)
        fileOpen(action->data().toString());
}

void MainWindow::refresh()
{
    // What the Refresh function does depends on the currently active tab. This way the keyboard shortcuts (F5 and Ctrl+R)
    // always perform some meaningful task; they just happen to be context dependent in the function they trigger.
    switch(ui->mainTab->currentIndex())
    {
    case StructureTab:
        // Refresh the schema
        db.updateSchema();
        break;
    case BrowseTab:
        // Refresh the schema and reload the current table
        db.updateSchema();
        populateTable();
        break;
    }
}

void MainWindow::switchToBrowseDataTab(QString tableToBrowse)
{

    // If no table name was provided get the currently selected table fromt he structure tab
    if(tableToBrowse.isEmpty())
    {
        // Cancel here if there is no selection
        if(!ui->dbTreeWidget->selectionModel()->hasSelection())
            return;

        tableToBrowse = ui->dbTreeWidget->model()->data(ui->dbTreeWidget->currentIndex().sibling(ui->dbTreeWidget->currentIndex().row(), 0)).toString();
    }

    ui->browse_T_ComboBox->setCurrentIndex(ui->browse_T_ComboBox->findText(tableToBrowse));
    ui->mainTab->setCurrentIndex(BrowseTab);

}

void MainWindow::clearTableBrowser()
{
    if (!ui->dataTable->model())
        return;

    ui->dataTable->setModel(0);
    if(qobject_cast<FilterTableHeader*>(ui->dataTable->horizontalHeader()))
        qobject_cast<FilterTableHeader*>(ui->dataTable->horizontalHeader())->generateFilters(0);
}

void MainWindow::populateStructure()
{
    QString old_table = ui->browse_T_ComboBox->currentText();

    // Refresh the structure tab
    dbStructureModel->reloadData();

    // Show the 'All' part of the db structure
    //ui->dbTreeWidget->setRootIndex(dbStructureModel->index(1, 0));
    //ui->dbTreeWidget->expandToDepth(0);

    // Refresh the browse data tab
    ui->browse_T_ComboBox->setRootModelIndex(dbStructureModel->index(0, 0)); // Show the 'browsable' section of the db structure tree
    int old_table_index = ui->browse_T_ComboBox->findText(old_table);
    if(old_table_index == -1 && ui->browse_T_ComboBox->count())      // If the old table couldn't be found anymore but there is another table, select that
        ui->browse_T_ComboBox->setCurrentIndex(0);
    else if(old_table_index == -1)                                  // If there aren't any tables to be selected anymore, clear the table view
        clearTableBrowser();
    else                                                            // Under normal circumstances just select the old table again
        ui->browse_T_ComboBox->setCurrentIndex(old_table_index);

    // Cancel here if no database is opened
    if(!db.isOpen())
        return;

    // Update table and column names for syntax highlighting
    objectMap tab = db.getBrowsableObjects();
    SqlUiLexer::TablesAndColumnsMap tablesToColumnsMap;
    for(auto it=tab.constBegin();it!=tab.constEnd();++it)
    {
        QString objectname = it.value().getname();

        for(int i=0; i < (*it).table.fields().size(); ++i)
        {
            QString fieldname = (*it).table.fields().at(i)->name();
            tablesToColumnsMap[objectname].append(fieldname);
        }
    }
    SqlTextEdit::sqlLexer->setTableNames(tablesToColumnsMap);
    ui->editLogApplication->reloadKeywords();
    ui->editLogUser->reloadKeywords();

    // Resize SQL column to fit contents
    ui->dbTreeWidget->resizeColumnToContents(3);
}

void MainWindow::populateTable()
{

    // Early exit if the Browse Data tab isn't visible as there is no need to update it in this case
    if(ui->mainTab->currentIndex() != BrowseTab)
        return;

    // Remove the model-view link if the table name is empty in order to remove any data from the view
    if(ui->browse_T_ComboBox->model()->rowCount(ui->browse_T_ComboBox->rootModelIndex()) == 0)
    {
        clearTableBrowser();
        return;
    }

    QApplication::setOverrideCursor(Qt::WaitCursor);

    // Get current table name
    QString tablename = ui->browse_T_ComboBox->currentText();

    // Set model
    bool reconnectSelectionSignals = false;

    if(ui->dataTable->model() == 0)
        reconnectSelectionSignals = true;

    ui->dataTable->setModel(m_browseTableModel);

    if(reconnectSelectionSignals)
        connect(ui->dataTable->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(dataTableSelectionChanged(QModelIndex)));

    // Search stored table settings for this table
    auto tableIt = browseTableSettings.constFind(tablename);
    bool storedDataFound = tableIt != browseTableSettings.constEnd();

    // Set new table
    if(!storedDataFound)
    {
        m_browseTableModel->setTable(tablename);
    } else {
        QVector<QString> v;
        bool only_defaults = true;
        for(int i=0;i<db.getObjectByName(tablename).table.fields().size();i++)
        {
            QString format = tableIt.value().displayFormats[i+1];
            if(format.size())
            {
                v.push_back(format);
                only_defaults = false;
            } else {
                v.push_back(sqlb::escapeIdentifier(db.getObjectByName(tablename).table.fields().at(i)->name()));
            }
        }
        if(only_defaults)
            m_browseTableModel->setTable(tablename);
        else
            m_browseTableModel->setTable(tablename, v);
    }

    // Restore table settings
    if(storedDataFound)
    {
        // There is information stored for this table, so extract it and apply it

        // Show rowid column. Needs to be done before the column widths setting because of the workaround in there and before the filter setting
        // because of the filter row generation.
        showRowidColumn(tableIt.value().showRowid);

        // Column widths
        for(auto widthIt=tableIt.value().columnWidths.constBegin();widthIt!=tableIt.value().columnWidths.constEnd();++widthIt)
            ui->dataTable->setColumnWidth(widthIt.key(), widthIt.value());

        // Sorting
        m_browseTableModel->sort(tableIt.value().sortOrderIndex, tableIt.value().sortOrderMode);
        ui->dataTable->filterHeader()->setSortIndicator(tableIt.value().sortOrderIndex, tableIt.value().sortOrderMode);

        // Filters
        FilterTableHeader* filterHeader = qobject_cast<FilterTableHeader*>(ui->dataTable->horizontalHeader());
        for(auto filterIt=tableIt.value().filterValues.constBegin();filterIt!=tableIt.value().filterValues.constEnd();++filterIt)
            filterHeader->setFilter(filterIt.key(), filterIt.value());

        // Encoding
        m_browseTableModel->setEncoding(tableIt.value().encoding);

    } else {
        // There aren't any information stored for this table yet, so use some default values

        // Hide rowid column. Needs to be done before the column widths setting because of the workaround in there
        showRowidColumn(false);

        // Column widths
        for(int i=1;i<m_browseTableModel->columnCount();i++)
            ui->dataTable->setColumnWidth(i, ui->dataTable->horizontalHeader()->defaultSectionSize());

        // Sorting
        m_browseTableModel->sort(0, Qt::AscendingOrder);
        ui->dataTable->filterHeader()->setSortIndicator(0, Qt::AscendingOrder);

        // Encoding
        m_browseTableModel->setEncoding(defaultBrowseTableEncoding);

    }

    // Activate the add and delete record buttons and editing only if a table has been selected
    bool editable = db.getObjectByName(tablename).gettype() == "table" && !db.readOnly();
    //ui->buttonNewRecord->setEnabled(editable);
    //ui->buttonDeleteRecord->setEnabled(editable);
    ui->dataTable->setEditTriggers(editable ? QAbstractItemView::SelectedClicked | QAbstractItemView::AnyKeyPressed | QAbstractItemView::EditKeyPressed : QAbstractItemView::NoEditTriggers);

    // Set the recordset label
    setRecordsetLabel();

    QApplication::restoreOverrideCursor();
}



bool MainWindow::fileClose()
{
    // Close the database but stop the closing process here if the user pressed the cancel button in there
    if(!db.close())
        return false;

    setWindowTitle(QApplication::applicationName());
    loadPragmas();
    statusEncryptionLabel->setVisible(false);
    statusReadOnlyLabel->setVisible(false);

    // Reset the model for the Browse tab
    m_browseTableModel->reset();

    // Remove all stored table information browse data tab
    browseTableSettings.clear();
    defaultBrowseTableEncoding = QString();

    // Reset the recordset label inside the Browse tab now
    setRecordsetLabel();

    activateFields(false);

    // Clear the SQL Log
    ui->editLogApplication->clear();
    ui->editLogUser->clear();

    return true;
}

void MainWindow::loadPragmas()
{
    pragmaValues.autovacuum = db.getPragma("auto_vacuum").toInt();
    pragmaValues.automatic_index = db.getPragma("automatic_index").toInt();
    pragmaValues.checkpoint_fullsync = db.getPragma("checkpoint_fullfsync").toInt();
    pragmaValues.foreign_keys = db.getPragma("foreign_keys").toInt();
    pragmaValues.fullfsync = db.getPragma("fullfsync").toInt();
    pragmaValues.ignore_check_constraints = db.getPragma("ignore_check_constraints").toInt();
    pragmaValues.journal_mode = db.getPragma("journal_mode").toUpper();
    pragmaValues.journal_size_limit = db.getPragma("journal_size_limit").toInt();
    pragmaValues.locking_mode = db.getPragma("locking_mode").toUpper();
    pragmaValues.max_page_count = db.getPragma("max_page_count").toInt();
    pragmaValues.page_size = db.getPragma("page_size").toInt();
    pragmaValues.recursive_triggers = db.getPragma("recursive_triggers").toInt();
    pragmaValues.secure_delete = db.getPragma("secure_delete").toInt();
    pragmaValues.synchronous = db.getPragma("synchronous").toInt();
    pragmaValues.temp_store = db.getPragma("temp_store").toInt();
    pragmaValues.user_version = db.getPragma("user_version").toInt();
    pragmaValues.wal_autocheckpoint = db.getPragma("wal_autocheckpoint").toInt();

    //updatePragmaUi();
}

void MainWindow::setRecordsetLabel()
{
    // Get all the numbers, i.e. the number of the first row and the last row as well as the total number of rows
    int from = ui->dataTable->verticalHeader()->visualIndexAt(0) + 1;
    int total = m_browseTableModel->totalRowCount();
    int to = ui->dataTable->verticalHeader()->visualIndexAt(ui->dataTable->height()) - 1;
    if (to == -2)
        to = total;

    // Update the validator of the goto row field
    gotoValidator->setRange(0, total);

    // Update the label showing the current position
    ui->labelRecordset->setText(tr("%1 - %2 of %3").arg(from).arg(to).arg(total));
}

void MainWindow::activateFields(bool enable)
{

}

void MainWindow::setCurrentFile(const QString &fileName)
{
    setWindowFilePath(fileName);
    setWindowTitle( QApplication::applicationName() +" - "+fileName);
    activateFields(true);
}

void MainWindow::loadExtensionsFromSettings()
{
    if(!db.isOpen())
        return;

    QStringList list = Settings::getSettingsValue("extensions", "list").toStringList();
    foreach(QString ext, list)
    {
        if(db.loadExtension(ext) == false)
            QMessageBox::warning(this, QApplication::applicationName(), tr("Error loading extension: %1").arg(db.lastErrorMessage));
    }
}

void MainWindow::dataTableSelectionChanged(const QModelIndex& index)
{
    // Cancel on invalid index
    if(!index.isValid()) {
        editDock->setCurrentIndex(QModelIndex());
        return;
    }

    bool editingAllowed = (m_currentTabTableModel == m_browseTableModel) &&
            (db.getObjectByName(ui->browse_T_ComboBox->currentText()).gettype() == "table");

    // Don't allow editing of other objects than tables
    editDock->setReadOnly(!editingAllowed);

    // If the Edit Cell dock is visible, load the new value into it
    if (editDock->isVisible()) {
        editDock->setCurrentIndex(index);
    }
}

void MainWindow::showRowidColumn(bool show)
{
    // Block all signals from the horizontal header. Otherwise the QHeaderView::sectionResized signal causes us trouble
    ui->dataTable->horizontalHeader()->blockSignals(true);

    // Show/hide rowid column
    ui->dataTable->setColumnHidden(0, !show);

    // Update checked status of the popup menu action
    ui->actionShowRowidColumn->setChecked(show);

    // Save settings for this table
    QString current_table = ui->browse_T_ComboBox->currentText();
    browseTableSettings[current_table].showRowid = show;

    // Update the filter row
    qobject_cast<FilterTableHeader*>(ui->dataTable->horizontalHeader())->generateFilters(m_browseTableModel->columnCount(), show);

    // Re-enable signals
    ui->dataTable->horizontalHeader()->blockSignals(false);

    ui->dataTable->update();
}

void MainWindow::createTreeContextMenu(const QPoint &qPoint)
{
    if(!ui->dbTreeWidget->selectionModel()->hasSelection())
        return;

    QString type = ui->dbTreeWidget->model()->data(ui->dbTreeWidget->currentIndex().sibling(ui->dbTreeWidget->currentIndex().row(), 1)).toString();

    if(type == "table" || type == "view" || type == "trigger" || type == "index")
        popupTableMenu->exec(ui->dbTreeWidget->mapToGlobal(qPoint));
}

void MainWindow::changeTreeSelection()
{
    // Just assume first that something's selected that can not be edited at all

    ui->editDeleteObjectAction->setEnabled(false);
    ui->editModifyTableAction->setEnabled(false);
    //ui->actionEditBrowseTable->setEnabled(false);

    if(!ui->dbTreeWidget->currentIndex().isValid())
        return;

    // Change the text and tooltips of the actions
    QString type = ui->dbTreeWidget->model()->data(ui->dbTreeWidget->currentIndex().sibling(ui->dbTreeWidget->currentIndex().row(), 1)).toString();

    if (type.isEmpty())
    {
        ui->editDeleteObjectAction->setIcon(QIcon(":icons/table_delete"));
    } else {
        ui->editDeleteObjectAction->setIcon(QIcon(QString(":icons/%1_delete").arg(type)));
    }

    if (type == "view") {
        ui->editDeleteObjectAction->setText(tr("Delete View"));
        ui->editDeleteObjectAction->setToolTip(tr("Delete View"));
    } else if(type == "trigger") {
        ui->editDeleteObjectAction->setText(tr("Delete Trigger"));
        ui->editDeleteObjectAction->setToolTip(tr("Delete Trigger"));
    } else if(type == "index") {
        ui->editDeleteObjectAction->setText(tr("Delete Index"));
        ui->editDeleteObjectAction->setToolTip(tr("Delete Index"));
    } else {
        ui->editDeleteObjectAction->setText(tr("Delete Table"));
        ui->editDeleteObjectAction->setToolTip(tr("Delete Table"));
    }

    // Activate actions
    if(type == "table")
    {
        ui->editDeleteObjectAction->setEnabled(!db.readOnly());
        ui->editModifyTableAction->setEnabled(!db.readOnly());
    } else if(type == "view" || type == "trigger" || type == "index") {
        ui->editDeleteObjectAction->setEnabled(!db.readOnly());
    }
    /*
    if(type == "table" || type == "view")
    {
        ui->actionEditBrowseTable->setEnabled(true);
        ui->actionExportCsvPopup->setEnabled(true);
    }
    */
}

void MainWindow::reloadSettings()
{
    // Read settings
    int prefetch_size = Settings::getSettingsValue("db", "prefetchsize").toInt();
    int log_fontsize = Settings::getSettingsValue("log", "fontsize").toInt();

    QFont logfont("Monospace");
    logfont.setStyleHint(QFont::TypeWriter);
    logfont.setPointSize(log_fontsize);

    // Set data browser font
    QFont dataBrowserFont(Settings::getSettingsValue("databrowser", "font").toString());
    dataBrowserFont.setPointSize(Settings::getSettingsValue("databrowser", "fontsize").toInt());
    ui->dataTable->setFont(dataBrowserFont);

    // Set prefetch sizes for lazy population of table models
    /*
    m_browseTableModel->setChunkSize(prefetch_size);
    for(int i=0; i < ui->tabSqlAreas->count(); ++i)
    {
        SqlExecutionArea* sqlArea = qobject_cast<SqlExecutionArea*>(ui->tabSqlAreas->widget(i));
        sqlArea->reloadSettings();
        sqlArea->getModel()->setChunkSize(prefetch_size);
        sqlArea->getResultView()->setFont(logfont);
    }
    */

    // Set font for SQL logs and edit dialog
    ui->editLogApplication->reloadSettings();
    ui->editLogUser->reloadSettings();
    ui->editLogApplication->setFont(logfont);
    ui->editLogUser->setFont(logfont);
    editDock->reloadSettings();

    // Load extensions
    loadExtensionsFromSettings();

    // Refresh view
    populateStructure();
    populateTable();

    /*
    // Hide or show the File → Remote menu as needed
    QAction *remoteMenuAction = ui->menuRemote->menuAction();
    remoteMenuAction->setVisible(Settings::getSettingsValue("remote", "active").toBool());
    */
    // Update the remote database connection settings
    m_remoteDb.reloadSettings();
}
